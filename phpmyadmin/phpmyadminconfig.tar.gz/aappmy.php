<?php
include "session.php"; include "functions.php";
if (!$rPermissions["is_admin"]) { exit; }

if  ($rSettings["sidebar"] && $rUserInfo["sidebarbru"]) {
    include "header_sidebarbru.php";
} 
elseif ($rSettings["sidebar"]) {
    include "header_sidebar.php";
} 
else {
    include "header.php";
}
        if (file_exists('/etc/letsencrypt/live'))
        {
              $hh = 'https';
              $domip =  $_SERVER['SERVER_NAME'];
        } 
        else 
        {
              $hh = 'http';
              $domip =  $_SERVER['SERVER_ADDR'];
        }
        if ($rSettings["sidebar"]) { ?>
        <div class="content-page"><div class="content"><div class="container-fluid">
        <?php } else { ?>
        <div class="wrapper"><div class="container-fluid">
        <?php }
		?>
                            <h4 class="page-title">PHPMYADMIN ACCESS</h4>
							
<html lang="en">
    <center><iframe src="<?=$hh?>://<?=$domip?>:<?=$_SERVER['SERVER_PORT']?>/phpmyadmin" style=" background: white; border: none; width: 1300px; height:600px; align: center"></iframe></center>
</html>       
                        </div>
                    </div>
                </div>     
               
                    </div><!-- end col -->
        <?php if ($rSettings["sidebar"]) { echo "</div>"; } ?>
        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 copyright text-center"><?=getFooter()?></div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->
        <script src="assets/js/vendor.min.js"></script>
        <script src="assets/libs/jquery-toast/jquery.toast.min.js"></script>
        <script src="assets/libs/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/libs/datatables/dataTables.bootstrap4.js"></script>
        <script src="assets/libs/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/libs/datatables/responsive.bootstrap4.min.js"></script>
        <script src="assets/js/app.min.js"></script>
    </body>
</html>