<?php
$server_ip = $_SERVER['SERVER_ADDR'];

?>
<!DOCTYPE html>
<html lang="en">
   <head>
<style>
body  {
  background-image: url("templates/images/lemp.png");
  background-color: #cccccc;
 /* Full height */
  height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;


}

body, html {
  height: 100%;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 60%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}
 
 h1{ 
        color: green; 
        text-align: center; 
      } 
      div.one{ 
        margin-top: 40px; 
        text-align: center; 
      } 
      button{ 
        margin-top: 10px; 
      } 

</style>

	<link type="text/css" rel="stylesheet" href="assets/css/bootstrap.min.css" />
 

     <mate charset="UTF-8">
     <title> Lemp </title>
   </head>
   <body>

<div class="hero-image">
  <div class="hero-text">
    <h1 style="font-size:50px">LEMP is Working !</h1>
</br>
<button type="button" class="btn btn-primary"> <a href="/phpmyadmin" style="color:inherit">phpMyAdmin</a> </button>
<button type="button" class="btn btn-secondary"> <a href="/info" style="color:inherit">PHP info</a> </button>
<button type="button" class="btn btn-success"> <a href="ftp://<?php echo $server_ip; ?>/" style="color:inherit">FTP</a> </button>
<button type="button" class="btn btn-danger" > <a href="https://github.com/lemp-info"  style="color:inherit" >GitHub</a> </button>
<button type="button" class="btn btn-danger" > <a href="http://www.lemp.info" style="color:inherit">WebSite</a> </button>
<button type="button" class="btn btn-warning"> <a href="http://bit.ly/34RjJrc" style="color:inherit">Donation</a> </button>
<a href="mailto:admin@lemp.info" target="_blank" class="btn btn-primary">Email Us</a>
</div>
</div>
 

<script src="assets/js/jquery-3.5.1.min.js"></script>
<script src="assets/js/script.js"></script>
   </body>
</html>