#!/bin/bash
# Modified by Matt Zuba in 2011 for cron job deletion
echo "Uninstalling DOS-Deflate"
echo; echo -n "Deleting cron job....."
/usr/local/sbin/ddos --remove-cron > /dev/null 2>&1
echo "done"

echo; echo -n "Deleting script files....."
if [ -e '/usr/local/sbin/ddos' ]; then
	rm -f /usr/local/sbin/ddos
	echo -n ".."
fi

if [ -d '/usr/local/ddos' ]; then
	rm -rf /usr/local/ddos
	echo -n ".."
fi
echo "done"
echo; echo "Uninstall Complete"; echo
