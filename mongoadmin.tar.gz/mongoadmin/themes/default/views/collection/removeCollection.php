<p class="message"><?php h($db);?> &raquo; <?php h($collection);?> <?php hm("dropped_from_database"); ?>.</p>
<script language="javascript">
window.parent.frames["left"].location.reload();
</script>