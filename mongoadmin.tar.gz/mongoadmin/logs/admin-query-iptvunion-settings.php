<?php exit("Permission Denied"); ?>
2022-06-26 18:10:22
array (
  'db' => 'iptvunion',
  'collection' => 'settings',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
