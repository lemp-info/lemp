<?php exit("Permission Denied"); ?>
2022-03-18 18:54:18
array (
  'db' => 'iptv_union',
  'collection' => 'reg_user',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
  "email": "latinhack@yahoo.com",
  "username": "ColombianoTV",
  "password": "aEhhVk1xdUFpWWEzaUNJWFBuZEhnQT09" 
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-03-18 18:54:35
array (
  'db' => 'iptv_union',
  'collection' => 'reg_user',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
  "email": "latinhack@yahoo.com",
  "username": "ColombianoTV",
  "password": "aEhhVk1xdUFpWWEzaUNJWFBuZEhnQT09" 
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-03-18 18:54:47
array (
  'db' => 'iptv_union',
  'collection' => 'reg_user',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
  "email": "latinhack@yahoo.com",
  "username": "ColombianoTV",
  "password": "aEhhVk1xdUFpWWEzaUNJWFBuZEhnQT09",
  "panelkey": "iu930yfe",
  "streamkey": "iu393jra",
  "member_group_id": "4",
  "access": [
    "all"
  ],
  "option_define": {
    "stream_define": "1",
    "account_define": "1",
    "tags_define": "3"
  },
  "option": {
    "stream": "0",
    "account": "0",
    "tv": "1",
    "tvscrambled": "1",
    "tags": "0"
  },
  "adminboss": "1",
  "adminsalar": "0",
  "admin_enabled": "1",
  "enabled": "1",
  "account_type": "basic",
  "activekey": "1214239499",
  "added": "1647469121",
  "id": "10"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-03-18 18:54:53
array (
  'action' => 'collection.index',
  'db' => 'iptv_union',
  'collection' => 'reg_user',
  'format' => 'json',
  'criteria' => '{
  "email": "latinhack@yahoo.com",
  "username": "ColombianoTV",
  "password": "aEhhVk1xdUFpWWEzaUNJWFBuZEhnQT09",
  "panelkey": "iu930yfe",
  "streamkey": "iu393jra",
  "member_group_id": "4",
  "access": [
    "all"
  ],
  "option_define": {
    "stream_define": "1",
    "account_define": "1",
    "tags_define": "3"
  },
  "option": {
    "stream": "0",
    "account": "0",
    "tv": "1",
    "tvscrambled": "1",
    "tags": "0"
  },
  "adminboss": "1",
  "adminsalar": "0",
  "admin_enabled": "1",
  "enabled": "1",
  "account_type": "basic",
  "activekey": "1214239499",
  "added": "1647469121",
  "id": "10"
}',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
