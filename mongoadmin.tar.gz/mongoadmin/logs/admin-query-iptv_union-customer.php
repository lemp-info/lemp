<?php exit("Permission Denied"); ?>
2022-03-19 09:54:44
array (
  'action' => 'collection.index',
  'db' => 'iptv_union',
  'collection' => 'customer',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2022-03-19 09:54:44
array (
  'action' => 'collection.index',
  'db' => 'iptv_union',
  'collection' => 'customer',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2022-03-19 18:39:56
array (
  'action' => 'collection.index',
  'db' => 'iptv_union',
  'collection' => 'customer',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
