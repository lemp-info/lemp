<?php exit("Permission Denied"); ?>
2022-06-20 17:39:01
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams_sys',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '7',
)
================
2022-06-20 17:39:23
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams_sys',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '6',
)
================
2022-06-21 22:29:58
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams_sys',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
2022-06-22 10:32:26
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams_sys',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '201',
)
================
