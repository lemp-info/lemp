<?php exit("Permission Denied"); ?>
2021-07-11 17:24:22
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2021-07-11 17:25:02
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2021-07-11 17:25:05
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'page' => '1',
)
================
2021-07-11 17:25:09
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'page' => '1',
)
================
2021-07-11 17:27:33
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2021-07-11 18:09:26
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2021-07-14 11:50:22
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2021-07-14 17:19:43
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '1',
)
================
2021-07-24 17:57:11
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_user',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
