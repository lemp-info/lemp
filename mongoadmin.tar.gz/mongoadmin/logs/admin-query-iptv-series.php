<?php exit("Permission Denied"); ?>
2022-09-06 15:19:15
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'series',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
