<?php exit("Permission Denied"); ?>
2022-05-27 13:47:55
array (
  'db' => 'iptvunion',
  'collection' => 'streaming_servers',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
 "server_ip": "5.196.189.83"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-05-27 13:48:06
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streaming_servers',
  'format' => 'array',
  'criteria' => 'array (
  \'server_ip\' => \'5.196.189.83\',
)',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
