<?php exit("Permission Denied"); ?>
2021-07-18 08:42:42
array (
  'db' => 'iptvunion',
  'collection' => 'server',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
  "panelkey": "iu068fdv",
  "name": "gulf",
  "ip": "5.196.189.850",
  "balancerport": "912",
  "streamport": "9821",
  "sshu": "root",
  "sshpass": "N3UrMUJXK01leWFHSXpxQ0l0VGtUUT09",
  "sshport": "22",
  "type": "main",
  "install": "1",
  "added": "1626553948"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-03-30 15:33:10
array (
  'db' => 'iptvunion',
  'collection' => 'server',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '1000',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-03-30 15:33:23
array (
  'db' => 'iptvunion',
  'collection' => 'server',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '1000',
  'pagesize' => '200',
  'command' => 'findAll',
)
================
2022-03-30 15:33:35
array (
  'db' => 'iptvunion',
  'collection' => 'server',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'limit' => '1000',
  'pagesize' => '200',
  'command' => 'findAll',
  'page' => '5',
)
================
2022-03-30 21:16:20
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'server',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2022-03-30 21:16:29
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'server',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '826',
)
================
2022-03-30 21:16:37
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'server',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '825',
)
================
2022-03-30 21:16:45
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'server',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '821',
)
================
2022-03-30 21:16:53
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'server',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '816',
)
================
2022-03-30 21:17:01
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'server',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '810',
)
================
2022-03-30 21:17:11
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'server',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '1',
)
================
2022-04-08 23:00:42
array (
  'db' => 'iptvunion',
  'collection' => 'server',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '
 { 
   "id": "1",
   "group_name": "Administrators",
   "group_color": "#FF0000",
   "is_banned": "0",
   "is_admin": "1",
   "is_reseller": "0",
   "is_sub_reseller": "0",
   "can_delete": "0" 
}	


',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
