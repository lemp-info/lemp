<?php exit("Permission Denied"); ?>
2022-05-01 12:10:44
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'reg_users',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
