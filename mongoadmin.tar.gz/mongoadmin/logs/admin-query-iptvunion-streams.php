<?php exit("Permission Denied"); ?>
2022-06-20 14:14:47
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '4',
)
================
2022-06-20 14:14:54
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '3',
)
================
2022-06-21 17:03:45
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '250',
)
================
2022-06-22 10:10:36
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2022-06-22 10:10:38
array (
  'action' => 'collection.index',
  'db' => 'iptvunion',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '201',
)
================
