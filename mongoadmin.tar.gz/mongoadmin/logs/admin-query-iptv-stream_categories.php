<?php exit("Permission Denied"); ?>
2023-01-04 08:20:08
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
2023-01-04 08:20:14
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '1',
)
================
2023-01-04 08:20:46
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '1',
)
================
2023-01-04 12:23:54
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '14',
)
================
2023-01-04 12:24:04
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '13',
)
================
2023-01-04 12:24:10
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
2023-01-04 12:24:30
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
2023-01-16 00:04:58
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2023-01-16 00:05:05
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '14',
)
================
2023-01-16 00:31:15
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '14',
)
================
2023-01-16 00:31:19
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '10',
)
================
2023-02-08 14:31:23
array (
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	 \'id\' => \'200
\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-02-08 14:31:31
array (
  'db' => 'iptv',
  'collection' => 'stream_categories',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	 \'id\' => \'200\'
 
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
