<?php exit("Permission Denied"); ?>
2022-12-12 15:08:33
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
   "id": "5869",

}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'desc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-12-12 15:08:43
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
   "id": "5869"

}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'desc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2022-12-12 15:08:53
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
   "id"=>"5869"

}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-08 08:03:11
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2330',
)
================
2023-01-08 15:36:50
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-08 15:36:58
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	 \'id\' => \'1005001\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-08 15:37:08
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	 \'id\' => \'1000001\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-08 15:41:43
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'id\' => \'1000001\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-10 12:01:14
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
2023-01-10 12:01:25
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2023-01-12 11:53:32
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	  \'id\' => \'35675\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-12 12:11:56
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'id\' => \'35675\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-13 14:20:46
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2023-01-13 14:21:20
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
 \'id\' => \'35675\',	
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-13 23:02:34
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"id"=>"35675"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-13 23:02:41
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
"id"=>"35675",
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-13 23:02:54
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2023-01-13 23:03:29
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array (
  \'id\'=>\'35675\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-14 13:11:49
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'id\'=>\'28759\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-14 13:17:23
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'id\'=>\'35675
\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-14 13:17:30
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'id\'=>\'35675\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-15 21:53:27
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'id\'=>\'28758\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-16 00:13:38
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2673',
)
================
2023-01-16 00:13:42
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2667',
)
================
2023-01-16 00:30:56
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2667',
)
================
2023-01-16 00:31:03
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2664',
)
================
2023-01-16 13:07:53
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
 \'id\'=>\'35675\'
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-01-16 13:08:32
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2023-01-16 13:08:40
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2023-01-16 13:08:57
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array (
\'id\'=>\'35675\'
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-02-08 14:30:50
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
  'page' => '11',
)
================
2023-02-08 15:29:57
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'streams',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'pagesize' => '10',
  'criteria' => 'array (
)',
  'command' => 'findAll',
)
================
2023-02-08 15:30:19
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array (
 \'_id\' => new MongoId("63e283ef35d785253f480812"),
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-02-08 15:30:26
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array (
 \'_id\' => new MongoId("63e283ef35d785253f480812"),
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-02-09 07:16:09
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
\'stream_display_name\' => \'Something from Tiffany\'s\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
2023-02-13 11:17:42
array (
  'db' => 'iptv',
  'collection' => 'streams',
  'action' => 'collection.index',
  'format' => 'array',
  'criteria' => 'array(
	\'id\' => \'1620583279\',
)',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
