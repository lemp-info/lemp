<?php exit("Permission Denied"); ?>
2023-08-06 09:00:52
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'server_activity',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
2023-08-06 09:01:01
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'server_activity',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
