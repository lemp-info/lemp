<?php exit("Permission Denied"); ?>
2022-03-19 20:53:50
array (
  'db' => 'iptv_union',
  'collection' => 'reg_users',
  'action' => 'collection.index',
  'format' => 'json',
  'criteria' => '{
  "id": "2",
  "key": "iu223fgd",
  "key_stream": "1234",
  "name": "fardin",
  "username": "fardin",
  "email": "fardin@gmail.com",
  "password": "dlRtSkF2WHZpLzVvdDNHTUdQak00Zz09",
  "group_name": "1",
  "enabled": "1"
}',
  'newobj' => '{
	\'$set\': {
		//your attributes
	}
}',
  'field' => 
  array (
    0 => '_id',
    1 => '',
    2 => '',
    3 => '',
  ),
  'order' => 
  array (
    0 => 'desc',
    1 => 'asc',
    2 => 'asc',
    3 => 'asc',
  ),
  'limit' => '0',
  'pagesize' => '10',
  'command' => 'findAll',
)
================
