<?php exit("Permission Denied"); ?>
2023-01-11 17:28:11
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '5',
)
================
2023-01-22 15:59:15
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '4',
)
================
2023-01-22 15:59:19
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '3',
)
================
2023-03-27 19:03:17
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '3',
)
================
2023-03-27 19:03:31
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '7',
)
================
2023-08-06 07:56:42
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '2',
)
================
2023-08-06 07:56:53
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '3',
)
================
2023-08-06 07:56:59
array (
  'action' => 'collection.index',
  'db' => 'iptv',
  'collection' => 'login_logs',
  'field' => 
  array (
    0 => '_id',
  ),
  'order' => 
  array (
    0 => 'desc',
  ),
  'format' => 'array',
  'newobj' => 'array(
	\'$set\' => array (
		//your attributes
	)
)',
  'pagesize' => '10',
  'criteria' => 'array(
	
)',
  'command' => 'findAll',
  'page' => '6',
)
================
