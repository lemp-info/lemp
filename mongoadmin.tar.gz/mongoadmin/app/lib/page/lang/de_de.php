<?php
/**
 * de_de
 * 
 * @since 1.0
 * @package if
 * @subpackage plugin.pager.lang
 */
$message["pager_prev"] = "Zurück";
$message["pager_next"] = "Weiter";
$message["pager_first"] = "Erste";
$message["pager_last"] = "Letzte";
$message["pager_input_pageno"] = "Springen zu:";
$message["pager_current_pageno"] = "Aktuell: %d ";
$message["pager_total_page"] = "Total: %d ";

?>