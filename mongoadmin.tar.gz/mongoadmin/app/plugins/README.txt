Put plugins here, and enable them in app/configs/rplugin.php
